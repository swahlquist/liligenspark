//= require application-preload.js
//= require action_cable
//= require vendor.js
//= require frontend.js

window.load_state = window.load_state || {};
window.load_state.state = "js_loaded";
window.load_state.js_loaded = true;