//= require simple_state.js
//= require globals.js

window.app_version = "2023.11.13b";
