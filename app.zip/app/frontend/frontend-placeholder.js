alert("You don't seem to have a compiled version of the ember code, so this placeholder is here to make things not barf too bad in the mean time.");
