import modal from '../utils/modal';

export default modal.ModalController.extend({
});