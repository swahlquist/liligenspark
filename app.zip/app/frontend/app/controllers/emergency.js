import { later as runLater } from '@ember/runloop';
import modal from '../utils/modal';
import i18n from '../utils/i18n';
import Controller from '@ember/controller';

export default Controller.extend({
  actions: {
  }
});
