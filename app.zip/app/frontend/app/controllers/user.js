import Controller from '@ember/controller';
import { observer } from '@ember/object';
import sync from '../utils/sync';

export default Controller.extend({
});
