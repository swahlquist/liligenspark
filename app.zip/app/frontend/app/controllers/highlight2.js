import highlight from './highlight';

export default highlight.extend({
});